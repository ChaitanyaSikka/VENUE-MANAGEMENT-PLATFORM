# 🏟️ Arenyx — Venue Management Platform

A real-time crowd management and venue operations platform built with **Next.js**, **Node.js**, **Socket.IO**, and **Google Gemini AI**.

---

## 📌 Features

- 🔴 **Real-time crowd monitoring** across gates and concession stands
- 🤖 **AI-powered attendee guide** using Google Gemini
- 🧑‍💼 **Admin dashboard** for staff communication and alert management
- 👥 **Attendee view** with live venue status and AI chat assistant
- 📡 **WebSocket-based live updates** via Socket.IO
- 🌙 **Dark/Light theme** support

---

## 🗂️ Project Structure

```
Arenyx-main/
├── arenyx/
│   ├── backend/          # Node.js + Express + Socket.IO server
│   │   ├── server.js         # Main server entry point
│   │   ├── crowdSimulator.js # Real-time crowd simulation logic
│   │   ├── geminiService.js  # Google Gemini AI integration
│   │   └── package.json
│   │
│   └── frontend/         # Next.js 14 app (TypeScript + Tailwind CSS)
│       ├── app/
│       │   ├── page.tsx          # Landing page
│       │   ├── admin/page.tsx    # Admin dashboard
│       │   └── attendee/page.tsx # Attendee view
│       ├── components/       # Reusable UI components
│       └── lib/socket.ts     # Socket.IO client setup
```

---

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) v18 or higher
- A [Google Gemini API Key](https://aistudio.google.com/)

---

### 1. Clone the repository

```bash
git clone https://github.com/jaybhakat07/VENUE-MANAGEMENT-PLATFORM.git
cd VENUE-MANAGEMENT-PLATFORM
```

---

### 2. Set up Backend

```bash
cd arenyx/backend
npm install
```

Create a `.env` file in the `backend/` folder:

```env
GEMINI_API_KEY=your_google_gemini_api_key_here
PORT=4000
```

Start the backend server:

```bash
node server.js
```

> Backend runs at **http://localhost:4000**

---

### 3. Set up Frontend

Open a **new terminal**:

```bash
cd arenyx/frontend
npm install
npm run dev
```

> Frontend runs at **http://localhost:3000**

---

## 🖥️ Usage

| Role | URL |
|---|---|
| Landing Page | http://localhost:3000 |
| Admin Dashboard | http://localhost:3000/admin |
| Attendee View | http://localhost:3000/attendee |

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 14, TypeScript, Tailwind CSS |
| Backend | Node.js, Express.js |
| Real-time | Socket.IO |
| AI | Google Gemini API |
| Styling | Tailwind CSS |

---

## ⚙️ Environment Variables

| Variable | Description |
|---|---|
| `GEMINI_API_KEY` | Your Google Gemini API key |
| `PORT` | Backend server port (default: 4000) |

> ⚠️ **Never commit your `.env` file.** It is already listed in `.gitignore`.

---

## 📦 Future Improvements

- [ ] User authentication (admin login)
- [ ] Database integration for persistent data
- [ ] Push notifications for critical alerts
- [ ] Mobile-responsive improvements
- [ ] Multi-venue support

---

## 👤 Author

**Jay Bhakat**
- GitHub: [@jaybhakat07](https://github.com/jaybhakat07)

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).
